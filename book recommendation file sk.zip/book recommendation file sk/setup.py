from setuptools import setup

with open("README.md","r",encoding="utf-8") as f:
    long_description = f.read()

REPO_NAME = "Book-Recommender-system-Using-Machine-Learning"
AUTHOR_USER_NAME = "shamil-skm"
SRC_REPO = "src"
LIST_OF_REQUIRMENT = ['streamlit','numpy']

setup(
    name=SRC_REPO,
    version="0.0.1",
    author=AUTHOR_USER_NAME,
    description="A small package for movie recommender system",
    long_description=long_description,
    url=f"https://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}",
    author_email="shamil.skm56@gmail.com",
    packages=[SRC_REPO],
    python_requires =">=3.7",
    install_requires = LIST_OF_REQUIRMENT
)

